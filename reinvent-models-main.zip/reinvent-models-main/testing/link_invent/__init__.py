from testing.link_invent.vocabulary_tests import *
from testing.link_invent.model_vocabulary_tests import *
from testing.link_invent.dataset_tests import *
from testing.link_invent.model_tests import *
from testing.link_invent.networks_tests import *
