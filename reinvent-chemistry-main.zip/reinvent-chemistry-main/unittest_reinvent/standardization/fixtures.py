class MockLogger:
    @staticmethod
    def log_message(message):
        print(message)

